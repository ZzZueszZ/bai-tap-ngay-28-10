package pakira.tech.bai_tap_28_10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaiTap2810Application {

	public static void main(String[] args) {
		SpringApplication.run(BaiTap2810Application.class, args);
	}

}
