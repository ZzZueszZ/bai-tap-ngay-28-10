package pakira.tech.bai_tap_28_10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaiTap2810ApplicationTests {

	@Test
	void contextLoads() {
	}

}
